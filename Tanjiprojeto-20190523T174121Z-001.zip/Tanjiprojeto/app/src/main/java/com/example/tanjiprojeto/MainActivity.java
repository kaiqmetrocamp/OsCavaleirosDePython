package com.example.tanjiprojeto;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {

    EditText med1, med2, med3;
    Button btnCalcular;
    TextView etEnvia;
    Button btnLimpar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        med1 = (EditText) findViewById(R.id.med1);
        med2 = (EditText) findViewById(R.id.med2);
        med3 = (EditText) findViewById(R.id.med3);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);
        etEnvia = (TextView) findViewById(R.id.etEnvia);
        btnLimpar = (Button) findViewById(R.id.btnLimpar);

    }

    public void onClickbtnlimpar(View view) {

        med1.setText("");
        med2.setText("");
        med3.setText("");
    }

    public void onClickbtnCalcular(View view) {

        double a = Double.parseDouble(med1.getText().toString());
        double b = Double.parseDouble(med2.getText().toString());
        double c = Double.parseDouble(med3.getText().toString());

        double Soma = a + b + c;
        double Divisor = Soma / 2;

        double operacion1 = Divisor - a;
        double operacion2 = Divisor - b;
        double operacion3 = Divisor - c;
        double Multiplicação = Divisor * operacion1 * operacion2 * operacion3;
        double raiz = Math.sqrt(Multiplicação);

        etEnvia.setText("Area = " + raiz);


        Intent intent = new Intent(MainActivity.this, Main2Activity.class);
        intent.putExtra("Chave", etEnvia.getText().toString());
        startActivity(intent);
        finish();


    }
}



